
  Hello,

the file GRFX_MOD.PRG is a self-extracting LZH packed file which 
contains all the graphix and the modplayer source and the ibytes 
files for this sources. Just copy it to your hard-drive or to another 
disk and double-click on it... It will generate all the files which 
couldn't be included unpacked on the disk because of disk space
problems...

      CU, the Fate of Unlimited Matricks


