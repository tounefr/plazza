          Persistence Of Vision Official Source Code Disc 1 (POVOSCD1)
          ------------------------------------------------------------


                   This source code disc has been released by
             PERSISTENCE OF VISION for use by others for NON-Profit
       making purposes only. The code is supplied as is and no claim can
        be made against PERSISTENCE OF VISION for loses incurred through
                          the use and/or abuse of it.


     PERSISTENCE OF VISION gives no guarantee that the code is functional,
   it is supplied as taken from backup discs stored by PERSISTENCE OF VISION.


    PERSISTENCE OF VISION regrets that no help can be given in modifying the
                  code or fixing modifications made by others.


             All soundtracks are copyright of the original authors


                                  Mac Sys Data
                                  P.O. Box 40
                               Thornton-Cleveleys
                                    FY5 3PH
                                   Lancashire
                                    England


                                  MSD 28/12/93




